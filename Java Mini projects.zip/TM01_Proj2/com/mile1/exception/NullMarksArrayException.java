package TM01_Proj2.com.mile1.exception;

public class NullMarksArrayException extends Exception{
	@Override
	public String toString() {
		return "NullMarksArrayException Occured";
	}
}
