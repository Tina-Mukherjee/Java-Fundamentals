package TM03_Proj1;
import java.util.Scanner;

public class InterestCalculator {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int choice=0;
		do {
			System.out.print("\nMAIN MENU"+"\n----------");
			System.out.print("\n1. Iterest Calculator - SB: ");
			System.out.print("\n2. Iterest Calculator - FD: ");
			System.out.print("\n3. Iterest Calculator - RD: ");
			System.out.print("\n4. Exit: ");
			System.out.print("\nEnter your option(1..4): ");
			choice = sc.hasNextInt() ? sc.nextInt():0;
			
			switch(choice) {
			case 1:
				SBAccount sb = new SBAccount();
				System.out.print("\nEnter the average amount in your account: ");
				sb.setAmount(sc.nextDouble());
				System.out.println("Interest Gained: Rs. "+sb.calculateInterest());
				break;
				
			case 2:
				FDAccount fd = new FDAccount();
				System.out.println("Enter the FD Amount: ");
				fd.setAmount(sc.nextDouble());
				
				System.out.println("Enter number of days: ");
				int noOfDays = sc.nextInt();
				while(noOfDays<0) {
					System.out.println("Invalid number of days. Please enter non-negative values.");
					System.out.println("Enter number of days: ");
					noOfDays = sc.nextInt();
				}
				fd.setNoOfDays(noOfDays);
				
				System.out.println("Enter your age: ");
				int age = sc.nextInt();
				while(age<0) {
					System.out.println("Invalid age. Please enter non-negative values.");
					System.out.println("Enter your age: ");
					age = sc.nextInt();
				}
				fd.setAgeOfACHolder(age);
				
				System.out.println("Interest Gained: Rs. "+fd.calculateInterest());
				break;
				
			case 3:
				RDAccount rd = new RDAccount();
				System.out.println("Enter the RD Amount: ");
				rd.setAmount(sc.nextDouble());
				
				System.out.println("Enter number of months: ");
				int noOfMonths = sc.nextInt();
				while(noOfMonths<0) {
					System.out.println("Invalid number of months. Please enter non-negative values.");
					System.out.println("Enter number of months: ");
					noOfMonths = sc.nextInt();
				}
				rd.setNoOfMonth(noOfMonths);
				
				System.out.println("Enter your age: ");
				age = sc.nextInt();
				while(age<0) {
					System.out.println("Invalid age. Please enter non-negative values.");
					System.out.println("Enter your age: ");
					age = sc.nextInt();
				}
				rd.setAgeOfACHolder(age);
				
				System.out.println("Interest Gained: Rs. "+rd.calculateInterest());
				break;
				
			case 4:
				System.out.println("Thanks for using Interest Calculator.");
				break;
				
			default:
				break;
			}
		}while(choice != 4);
		sc.close();
	}
}