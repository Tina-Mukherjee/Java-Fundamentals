package TM07_Proj2;

import java.util.ArrayList;
import java.util.List;

public class Items {
	static List<String> list = new ArrayList<>();
	
	public static boolean insert(String item) {
		if(!list.contains(item)) {
			list.add(item);
			return true;
		}
		return false;
	}
	
	public static boolean search(String item) {
		if(list.contains(item)) {
			return true;
		}
		return false;
	}
	
	public static boolean delete(String item) {
		if(list.contains(item)) {
			list.remove(item);
			return true;
		}
		return false;
	}
	
	public static void display() {
		for(String item : list)
			System.out.println(item);
	}
}
