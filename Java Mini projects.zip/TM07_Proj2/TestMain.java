package TM07_Proj2;

import java.util.Scanner;

public class TestMain {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int choice =0;
		
		do {
			System.out.println("1. Insert\n2. Search\n3. Delete\n4. Display\n5. Exit");
			System.out.println("Enter your choice: ");
			choice = sc.nextInt();
			sc.nextLine();
			
			switch(choice) {
			case 1:
				System.out.print("Enter the item to be inserted: ");
				if(Items.insert(sc.nextLine()))
					System.out.println("Inserted Successfully");
				else
					System.out.println("Already Exists");
				break;
				
			case 2:
				System.out.print("Enter the item to search: ");
				if(Items.search(sc.nextLine()))
					System.out.println("Item found in the List");
				else
					System.out.println("Item not found in the List");
				break;
				
			case 3:
				System.out.print("Enter the item to delete: ");
				if(Items.delete(sc.nextLine()))
					System.out.println("Deleted Successfully");
				else
					System.out.println("Item does not exist");
				break;
				
			case 4:
				System.out.println("The items in the list are: ");
				Items.display();
				break;
				
			case 5:
				break;
				
			default:
				System.out.println("Invalid Input");
				break;
			}
		}while(choice!=5);
		sc.close();
	}
}
