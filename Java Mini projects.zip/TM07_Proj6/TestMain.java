package TM07_Proj6;

import java.util.ArrayList;
import java.util.List;

public class TestMain {
	public static void main(String args[]) {
		String s1 = "JAVAJAVA";
		String s2 = "VA";
		
		List<String> list = doOperations(s1, s2);
		System.out.println("Output: "+list);
	}
	public static List<String> doOperations(String s1, String s2){
		List<String> list = new ArrayList<String>();
		
		StringBuilder sb = new StringBuilder();
		for(int i=1; i< s1.length(); i += 2) {
			sb.append(s2);
			sb.append(s1.charAt(i));
		}
		list.add(sb.toString());
		
		int occurence = s1.split(s2, -1).length - 1;
		if(occurence > 1)
			list.add(s1.substring(0, s1.lastIndexOf(s2))+ new StringBuilder(s2).reverse());
		
		if(occurence > 1)
			list.add(s1.substring(0, s1.indexOf(s2)) + s1.substring(s1.indexOf(s2) + s2.length(), s1.length()));
		
		int partLength = s2.length() % 2 == 0 ? s2.length()/2 : s2.length()/2 + 1;
		list.add(s2.substring(0, partLength) + s1 + s2.substring(partLength, s2.length()));
		
		sb = new StringBuilder();
		for(int i=0; i<s1.length(); i++) {
			if(s2.indexOf(s1.charAt(i)) != -1)
				sb.append('*');
			else
				sb.append(s1.charAt(i));
		}
		list.add(sb.toString());
		
		return list;
	}
}
