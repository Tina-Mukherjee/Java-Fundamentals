package TM07_Proj5;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class TestMain {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		Set<Box> set = new TreeSet<>();
		
		System.out.println("Enter the number of boxes: ");
		int n = sc.nextInt();
		
		for(int i=1; i<=n; i++) {
			Box box = new Box();
			System.out.println("Enter the Box "+i+" Details");
			
			System.out.println("Enter length");
			box.setLength(sc.nextDouble());
			System.out.println("Enter width");
			box.setWidth(sc.nextDouble());
			System.out.println("Enter height");
			box.setHeight(sc.nextDouble());
			
			set.add(box);
		}
		System.out.println("Unique Boxes int the Set are");
		for(Box box : set)
			System.out.println(box);
		sc.close();
	}
}
