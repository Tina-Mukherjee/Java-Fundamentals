package TM07_Proj1;

import java.util.*;

public class TestMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number of employees: ");
		int empCount = sc.nextInt();
		sc.nextLine();
		
		List<Employee> empList = new ArrayList<>();
		
		for(int i=0; i<empCount; i++) {
			System.out.print("Enter Employee "+(i+1)+" Details:\n");
			System.out.print("Enter the First Name: ");
			String fname = sc.nextLine(); 
			System.out.print("Enter the Last Name: ");
			String lname = sc.nextLine(); 
			System.out.print("Enter the Mobile Number: ");
			long mob = sc.nextLong(); 
			sc.nextLine();
			System.out.print("Enter the Email: ");
			String email = sc.nextLine(); 
			System.out.print("Enter the Address: ");
			String address = sc.nextLine(); 
			
			empList.add(new Employee(fname, lname, mob, email, address));
		}
		
		Collections.sort(empList);
		
		System.out.println("Employee List: \n");
		System.out.format("%-15s %-15s %-15s %-30s %-15s\n","Firstname","Lastname","Mobile","Email","Address");
		for(int i=0; i<90; i++)
			System.out.print("-");
		System.out.println();
		
		Iterator<Employee> it = empList.iterator();
		while(it.hasNext()) {
			Employee emp = it.next();
			System.out.format("%-15s %-15s %-15s %-30s %-15s\n", emp.getFirstName(), emp.getLastName(), emp.getMobileNumber(), emp.getEmailId(), emp.getAddress());
			
		}
		for(int i=0; i<90; i++)
			System.out.print("-");
		sc.close();
	}
		
}


