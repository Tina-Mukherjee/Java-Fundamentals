package TM07_Proj1;

public class Employee implements Comparable<Employee>{
	String fname, lname, email, address;
	long mob;
	
	public Employee() {
		super();
	}
	
	public Employee(String fname, String lname, long mob, String email, String address) {
		super();
		this.fname=fname;
		this.lname=lname;
		this.mob=mob;
		this.email=email;
		this.address=address;
	}
	
	public String getFirstName() {
		return fname;
	}
	
	public String getLastName() {
		return lname;
	}
	
	public long getMobileNumber() {
		return mob;
	}
	
	public String getEmailId() {
		return email;
	}
	
	public String getAddress() {
		return address;
	}
	
	@Override
	public String toString() {
		return "Employee [FirstName= "+fname+", LastName= "+lname+", MobileNumber= "+mob+", Email= "+email+", Address= "+address+"]";
	}
	
	public int compareTo(Employee emp) {
		return this.fname.compareTo(emp.getFirstName()) * -1;
	}
	

}
