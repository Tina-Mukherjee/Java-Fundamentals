package TM04_Proj2;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import TM03_Proj1.RDAccount;

public class RDAccountTest {
	RDAccount rd = new RDAccount();
	
	@Test
	public void setAmountTest() {
		rd.setAmount(10000.0);
		assertEquals(10000.0, rd.getAmount(), 0.0);
	}
	
	@Test
	public void getSetInterestTest() {
		rd.setInterestRate(5);
		assertEquals(5, rd.getInterestRate(), 0);
	}
	
	@Test
	public void getSetNoOfMonthTest() {
		rd.setNoOfMonth(6);;
		assertEquals(6, rd.getNoOfMonth());
	}
	
	@Test
	public void getSetMonthlyAmountTest() {
		rd.setMonthlyAmount(500);
		assertEquals(500, rd.getMonthlyAmount(), 0);
	}
	
	@Test
	public void getSetAgeOfACHolderTest() {
		rd.setAgeOfACHolder(65);
		assertEquals(65, rd.getAgeOfACHolder());
	}
	
	@Test
	public void calculateInterestTest() {
		rd.setAmount(10000.0);
		rd.setNoOfMonth(6);
		rd.setAgeOfACHolder(65);
		assertEquals(800.0, rd.calculateInterest(), 0.0);
	}
}
