package TM04_Proj2;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import TM03_Proj1.SBAccount;

public class SBAccountTest {
	SBAccount sb = new SBAccount();
	
	@Test
	public void getSetAmountTest() {
		sb.setAmount(10000.0);
		assertEquals(10000.0, sb.getAmount(), 0.0);
	}
	
	@Test
	public void getSetInterestTest() {
		sb.setInterestRate(5);
		assertEquals(5, sb.getInterestRate(), 0);
	}
	
	@Test
	public void calculateInterestTest() {
		sb.setAmount(10000.0);
		assertEquals(400.0, sb.calculateInterest(), 0.0);
	}
}
