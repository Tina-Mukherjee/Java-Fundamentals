package TM04_Proj2;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import TM03_Proj1.FDAccount;

public class FDAccountTest {
	FDAccount fd = new FDAccount();
	
	@Test
	public void setAmountTest() {
		fd.setAmount(10000.0);
		assertEquals(10000.0, fd.getAmount(), 0.0);
	}
	
	@Test
	public void getSetInterestTest() {
		fd.setInterestRate(5);
		assertEquals(5, fd.getInterestRate(), 0);
	}
	
	@Test
	public void getSetNoOfDaysTest() {
		fd.setNoOfDays(91);;
		assertEquals(91, fd.getNoOfDays());
	}
	
	@Test
	public void getSetAgeOfACHolderTest() {
		fd.setAgeOfACHolder(65);
		assertEquals(65, fd.getAgeOfACHolder());
	}
	
	@Test
	public void calculateInterestTest() {
		fd.setAmount(10000.0);
		fd.setNoOfDays(91);
		fd.setAgeOfACHolder(65);
		assertEquals(800.0, fd.calculateInterest(),0.0);
		
		fd.setAmount(10000.0);
		fd.setNoOfDays(91);
		fd.setAgeOfACHolder(30);
		assertEquals(750.0, fd.calculateInterest(),0.0);
	}
}
